import React, { useState } from 'react';
import { Layout, Menu, Card, Button, Input, Select, Collapse, Space, Typography, Badge, Dropdown, message, Table } from 'antd';
import { 
  ExperimentOutlined, 
  PlusOutlined, 
  MoreOutlined, 
  DragOutlined,
  PlayCircleOutlined,
  DeleteOutlined,
  CopyOutlined,
  SaveOutlined,
  FolderOpenOutlined
} from '@ant-design/icons';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import {
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import DocumentManager from './DocumentManager';
import './PromptStudio.css';

const { Sider, Content } = Layout;
const { TextArea } = Input;
const { Option } = Select;
const { Panel } = Collapse;
const { Title, Text } = Typography;

// 可排序的算子卡片组件
const SortableOperatorCard = ({ operator, onOperatorChange, onRunOperator, onDeleteOperator, onDuplicateOperator }) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(operator.name);

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: operator.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'enabled': return 'green';
      case 'running': return 'blue';
      case 'pending': return 'orange';
      case 'error': return 'red';
      default: return 'gray';
    }
  };

  const handleNameEdit = () => {
    setIsEditingName(true);
    setTempName(operator.name);
  };

  const handleNameSave = () => {
    if (tempName.trim() && tempName !== operator.name) {
      onOperatorChange(operator.id, 'name', tempName.trim());
    }
    setIsEditingName(false);
  };

  const handleNameCancel = () => {
    setTempName(operator.name);
    setIsEditingName(false);
  };

  const operatorMenuItems = [
    {
      key: '1',
      label: 'Rename',
      onClick: handleNameEdit
    },
    {
      key: '2',
      label: 'Duplicate',
      icon: <CopyOutlined />,
      onClick: () => onDuplicateOperator(operator.id)
    },
    {
      key: '3',
      label: 'Delete',
      icon: <DeleteOutlined />,
      danger: true,
      onClick: () => onDeleteOperator(operator.id)
    }
  ];

  return (
    <Card 
      ref={setNodeRef}
      style={style}
      className="operator-card"
      size="small"
    >
      <div className="operator-header">
        <div className="operator-info">
          <Space>
            <DragOutlined 
              className="drag-handle" 
              {...attributes} 
              {...listeners}
            />
            {isEditingName ? (
              <Space size="small">
                <Input
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  onPressEnter={handleNameSave}
                  onBlur={handleNameSave}
                  size="small"
                  style={{ width: 120 }}
                  autoFocus
                />
                <Button size="small" type="text" onClick={handleNameCancel}>✕</Button>
              </Space>
            ) : (
              <Badge 
                status={getStatusColor(operator.status)} 
                text={
                  <span 
                    onDoubleClick={handleNameEdit}
                    style={{ cursor: 'pointer', userSelect: 'none' }}
                    title="Double click to edit"
                  >
                    {operator.name}
                  </span>
                }
              />
            )}
          </Space>
        </div>
        <div className="operator-actions">
          <Button
            size="small"
            icon={<PlayCircleOutlined />}
            onClick={() => onRunOperator(operator.id)}
            loading={operator.status === 'running'}
          >
            Run
          </Button>
          <Dropdown
            menu={{ items: operatorMenuItems }}
            trigger={['click']}
          >
            <Button size="small" icon={<MoreOutlined />} />
          </Dropdown>
        </div>
      </div>

      <div className="operator-content">
        <Space direction="vertical" style={{ width: '100%' }} size="small">
          <div>
            <Text strong>Type:</Text>
            <Select
              value={operator.type}
              onChange={(value) => onOperatorChange(operator.id, 'type', value)}
              style={{ width: '100%', marginTop: 4 }}
              size="small"
            >
              <Option value="extract">Extract</Option>
              <Option value="filter">Filter</Option>
              <Option value="transform">Transform</Option>
              <Option value="validate">Validate</Option>
            </Select>
          </div>

          <div>
            <Text strong>Prompt:</Text>
            <TextArea
              value={operator.prompt}
              onChange={(e) => onOperatorChange(operator.id, 'prompt', e.target.value)}
              placeholder="Enter your prompt here..."
              rows={3}
              style={{ marginTop: 4 }}
            />
          </div>

          <div>
            <Text strong>Model:</Text>
            <Select
              value={operator.model}
              onChange={(value) => onOperatorChange(operator.id, 'model', value)}
              style={{ width: '100%', marginTop: 4 }}
              size="small"
            >
              <Option value="gpt-4o">gpt-4o</Option>
              <Option value="gpt-3.5-turbo">gpt-3.5-turbo</Option>
              <Option value="claude-3">claude-3</Option>
            </Select>
          </div>

          {operator.output && (
            <Collapse size="small">
              <Panel header="Output Result" key="1">
                {(() => {
                  // 尝试解析为表格数据
                  try {
                    const data = JSON.parse(operator.output);
                    if (Array.isArray(data) && data.length > 0 && typeof data[0] === 'object') {
                      // DataFrame 格式：数组对象
                      const columns = Object.keys(data[0]).map(key => ({
                        title: key,
                        dataIndex: key,
                        key: key,
                        width: 120,
                      }));
                      
                      const dataSource = data.map((row, index) => ({
                        ...row,
                        key: index,
                      }));

                      return (
                        <Table
                          columns={columns}
                          dataSource={dataSource}
                          pagination={false}
                          size="small"
                          bordered
                          scroll={{ x: 'max-content' }}
                        />
                      );
                    }
                  } catch (e) {
                    // 如果不是 JSON 或不是表格格式，就显示原始文本
                  }
                  
                  // 默认显示文本
                  return <Text code style={{ whiteSpace: 'pre-wrap' }}>{operator.output}</Text>;
                })()}
              </Panel>
            </Collapse>
          )}
        </Space>
      </div>
    </Card>
  );
};

const PromptStudio = () => {
  const [operators, setOperators] = useState([
    {
      id: '1',
      name: 'test_1',
      type: 'extract',
      prompt: 'Enter Prompt',
      model: 'gpt-4o',
      status: 'enabled',
      output: null,
      collapsed: false
    },
    {
      id: '2',
      name: 'test_2',
      type: 'filter',
      prompt: 'Enter Prompt',
      model: 'gpt-4o',
      status: 'pending',
      output: null,
      collapsed: false
    }
  ]);

  const [documents, setDocuments] = useState([]);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event) => {
    const { active, over } = event;

    if (active.id !== over?.id) {
      setOperators((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id);
        const newIndex = items.findIndex((item) => item.id === over.id);

        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  const handleAddOperator = () => {
    const newOperator = {
      id: Date.now().toString(),
      name: `test_${operators.length + 1}`,
      type: 'extract',
      prompt: 'Enter Prompt',
      model: 'gpt-4o',
      status: 'pending',
      output: null,
      collapsed: false
    };
    setOperators([...operators, newOperator]);
  };

  const handleOperatorChange = (id, field, value) => {
    setOperators(operators.map(op => 
      op.id === id ? { ...op, [field]: value } : op
    ));
  };

  const handleRunOperator = (id) => {
    setOperators(operators.map(op => 
      op.id === id ? { ...op, status: 'running' } : op
    ));
    
    // 模拟API调用
    setTimeout(() => {
      setOperators(prev => prev.map(op => 
        op.id === id ? { 
          ...op, 
          status: 'enabled',
          output: JSON.stringify([
            {'Name': 'aaa', 'Age': 25, 'City': 'New 1111111111'},
            {'Name': 'bbb', 'Age': 30, 'City': '22222222222'},
            {'Name': 'ccc', 'Age': 35, 'City': '3333333'},
            {'Name': 'ddd', 'Age': 40, 'City': '444444444444444'}
          ])
          
        } : op
      ));
    }, 2000);
  };

  const handleDeleteOperator = (id) => {
    setOperators(operators.filter(op => op.id !== id));
  };

  const handleDuplicateOperator = (id) => {
    const operator = operators.find(op => op.id === id);
    if (operator) {
      const newOperator = {
        ...operator,
        id: Date.now().toString(),
        name: operator.name + '_copy'
      };
      setOperators([...operators, newOperator]);
    }
  };

  const handleDocumentAdd = (newDocument) => {
    setDocuments([...documents, newDocument]);
    message.success('文档添加成功！');
  };

  const handleDocumentDelete = (documentId) => {
    setDocuments(documents.filter(doc => doc.id !== documentId));
    message.success('文档删除成功！');
  };

  const handleSaveWorkflow = () => {
    const workflow = {
      operators,
      documents: documents.map(doc => ({ id: doc.id, name: doc.name })),
      timestamp: new Date().toISOString()
    };
    console.log('Saving workflow:', workflow);
    message.success('工作流保存成功！');
  };

  const handleRunAllOperators = () => {
    const pendingOperators = operators.filter(op => op.status === 'pending' || op.status === 'enabled');
    
    if (pendingOperators.length === 0) {
      message.info('没有需要运行的算子');
      return;
    }

    // 设置所有算子为运行状态
    setOperators(prev => prev.map(op => 
      pendingOperators.find(pending => pending.id === op.id) 
        ? { ...op, status: 'running' } 
        : op
    ));

    // 模拟依次运行所有算子
    pendingOperators.forEach((operator, index) => {
      setTimeout(() => {
        setOperators(prev => prev.map(op => 
          op.id === operator.id ? {
            ...op,
            status: 'enabled',
            output: `Batch output for ${op.name}:\n\n${getRandomOutput(op.type)}`
          } : op
        ));
      }, (index + 1) * 1500);
    });

    message.success(`开始批量运行 ${pendingOperators.length} 个算子`);
  };

  const getRandomOutput = (type) => {
    const outputs = {
      extract: 'Extracted entities:\n- Person: Mengna Zhu, Kaisheng Zeng\n- Organization: National University of Defense Technology\n- Technology: LLMs, Event Extraction\n- Method: LC4EE',
      filter: 'Filtered results:\n- Relevant documents: 5\n- Filtered out: 2\n- Confidence score: 0.87',
      transform: 'Transformed data:\n- Format: JSON\n- Structure: Normalized\n- Fields: 12',
      validate: 'Validation results:\n- Status: PASSED\n- Errors: 0\n- Warnings: 1\n- Accuracy: 94.2%'
    };
    return outputs[type] || 'Processing completed successfully.';
  };

  return (
    <Layout className="prompt-studio" style={{ height: '100vh' }}>
      {/* 左侧导航栏 */}
      <Sider width={250} className="sidebar">
        <div className="logo">
          <Title level={4} style={{ color: 'white', margin: '16px' }}>
            Unstract
          </Title>
        </div>
        <Menu
          theme="dark"
          mode="inline"
          defaultSelectedKeys={['prompt-studio']}
          items={[
            {
              key: 'prompt-studio',
              icon: <ExperimentOutlined />,
              label: 'Prompt Studio',
            },
            {
              key: 'workflows',
              icon: <FolderOpenOutlined />,
              label: 'Workflows',
              
            }
          ]}
        />
      </Sider>

      {/* 主内容区域 */}
      <Layout>


        <Content className="main-content">
          <div className="content-wrapper">
            {/* 中间算子配置区域 */}
            <div className="operators-section">
              <div className="operators-header">
                <div>
                  <Title level={4}>Document Operator</Title>
                  <div className="workflow-status">
                    <Space size="large">
                      <Badge status="success" text={`${operators.filter(op => op.status === 'enabled').length} Completed`} />
                      <Badge status="processing" text={`${operators.filter(op => op.status === 'running').length} Running`} />
                      <Badge status="warning" text={`${operators.filter(op => op.status === 'pending').length} Pending`} />
                      <Badge status="error" text={`${operators.filter(op => op.status === 'error').length} Error`} />
                    </Space>
                  </div>
                </div>
                <Space>
                  <Button 
                    size="small"
                    onClick={handleRunAllOperators}
                    type="default"
                    disabled={operators.filter(op => op.status === 'pending' || op.status === 'enabled').length === 0}
                  >
                    Run All
                  </Button>
                  <Button 
                    size="small"
                    icon={<SaveOutlined />}
                    onClick={handleSaveWorkflow}
                  >
                    Save
                  </Button>
                  <Button 
                    type="primary" 
                    icon={<PlusOutlined />}
                    onClick={handleAddOperator}
                  >
                    Add Operator
                  </Button>
                </Space>
              </div>

              <div className="operators-list">
                <DndContext 
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext 
                    items={operators.map(op => op.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    {operators.map((operator) => (
                      <SortableOperatorCard
                        key={operator.id}
                        operator={operator}
                        onOperatorChange={handleOperatorChange}
                        onRunOperator={handleRunOperator}
                        onDeleteOperator={handleDeleteOperator}
                        onDuplicateOperator={handleDuplicateOperator}
                      />
                    ))}
                  </SortableContext>
                </DndContext>
              </div>
            </div>

            {/* 右侧文档展示区域 */}
            <div className="documents-section">
              <DocumentManager 
                documents={documents}
                onDocumentAdd={handleDocumentAdd}
                onDocumentDelete={handleDocumentDelete}
              />
            </div>
          </div>
        </Content>
      </Layout>
    </Layout>
  );
};

export default PromptStudio;
