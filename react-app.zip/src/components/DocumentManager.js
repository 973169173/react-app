import React, { useState } from 'react';
import { Card, Button, Space, Typography, Upload, message, Modal } from 'antd';
import { 
  UploadOutlined, 
  EyeOutlined, 
  DeleteOutlined, 
  DownloadOutlined,
  FileTextOutlined,
  FilePdfOutlined 
} from '@ant-design/icons';

const { Text, Paragraph } = Typography;

const DocumentManager = ({ documents, onDocumentAdd, onDocumentDelete }) => {
  const [previewVisible, setPreviewVisible] = useState(false);
  const [previewDocument, setPreviewDocument] = useState(null);
  // 展开全文的状态，key为doc.id
  const [expandedDocIds, setExpandedDocIds] = useState([]);

  const handlePreview = (document) => {
    if (document.type.includes('pdf') || document.name.toLowerCase().endsWith('.pdf')) {
      // 对于PDF文件，创建blob URL并在新窗口中打开
      if (document.file) {
        const fileURL = URL.createObjectURL(document.file);
        window.open(fileURL, '_blank');
      } else {
        message.error('PDF文件无法预览,文件数据缺失');
      }
    } else {
      // 对于文本文件，在模态框中显示
      setPreviewDocument(document);
      setPreviewVisible(true);
    }
  };

  const handleFileUpload = (file) => {
    const isValidType = file.type.includes('pdf') || 
                       file.type.includes('text') || 
                       file.name.toLowerCase().endsWith('.txt') ||
                       file.name.toLowerCase().endsWith('.pdf');
    if (!isValidType) {
      message.error('只支持 PDF, TXT 格式的文件！');
      return false;
    }
    
    const isLt10M = file.size / 1024 / 1024 < 10;
    if (!isLt10M) {
      message.error('文件大小不能超过 10MB!');
      return false;
    }

    const reader = new FileReader();
    
    reader.onload = (e) => {
      const newDocument = {
        id: Date.now(),
        name: file.name,
        content: file.type.includes('text') || file.name.toLowerCase().endsWith('.txt') 
          ? e.target.result 
          : null, // PDF文件不读取内容，直接存储File对象
        file: file, // 存储原始文件对象用于预览
        size: file.size,
        type: file.type || (file.name.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'text/plain'),
        uploadTime: new Date().toLocaleString()
      };
      
      if (onDocumentAdd) {
        onDocumentAdd(newDocument);
      }
      
      message.success(`${file.name} 上传成功！`);
    };

    reader.onerror = () => {
      message.error('文件读取失败！');
    };

    // 对于文本文件，读取为文本；对于PDF，只存储文件对象
    if (file.type.includes('text') || file.name.toLowerCase().endsWith('.txt')) {
      reader.readAsText(file, 'UTF-8');
    } else {
      // PDF文件直接处理，不读取内容
      const newDocument = {
        id: Date.now(),
        name: file.name,
        content: null,
        file: file,
        size: file.size,
        type: file.type || 'application/pdf',
        uploadTime: new Date().toLocaleString()
      };
      
      if (onDocumentAdd) {
        onDocumentAdd(newDocument);
      }
      
      message.success(`${file.name} 上传成功！`);
    }

    return false; // 阻止默认上传
  };

  const uploadProps = {
    name: 'file',
    multiple: true,
    accept: '.pdf,.txt',
    beforeUpload: handleFileUpload,
    showUploadList: false,
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (fileName) => {
    if (fileName.toLowerCase().includes('.pdf')) {
      return <FilePdfOutlined style={{ color: '#ff4d4f' }} />;
    }
    return <FileTextOutlined style={{ color: '#1890ff' }} />;
  };


  const handleExpand = (docId) => {
    setExpandedDocIds(prev => [...prev, docId]);
  };
  const handleCollapse = (docId) => {
    setExpandedDocIds(prev => prev.filter(id => id !== docId));
  };

  return (
    <div className="document-manager">
      <div className="documents-header">
        <Typography.Title level={4}>Documents</Typography.Title>
        <Space>
          <Upload {...uploadProps}>
            <Button size="small" icon={<UploadOutlined />}>
              Upload
            </Button>
          </Upload>
        </Space>
      </div>

      <div className="documents-list">
        {documents.map(doc => {
          const expanded = expandedDocIds.includes(doc.id);
          return (
            <Card 
              key={doc.id}
              className="document-card"
              size="small"
              title={
                <Space>
                  {getFileIcon(doc.name)}
                  <Text ellipsis style={{ maxWidth: 200 }}>{doc.name}</Text>
                  
                </Space>
              }
              extra={
                <Space>
                  <Button 
                    size="small" 
                    icon={<EyeOutlined />}
                    onClick={() => handlePreview(doc)}
                  >
                    Preview
                  </Button>
                  <Button 
                    size="small" 
                    icon={<DeleteOutlined />}
                    danger
                    onClick={() => onDocumentDelete && onDocumentDelete(doc.id)}
                  />
                </Space>
              }
            >
              <div className="document-info">
                {doc.size && (
                  <Text type="secondary" style={{ fontSize: '12px' }}>
                    Size: {formatFileSize(doc.size)}
                  </Text>
                )}
                {doc.uploadTime && (
                  <Text type="secondary" style={{ fontSize: '12px', display: 'block' }}>
                    Uploaded: {doc.uploadTime}
                  </Text>
                )}
              </div>
              <div className="document-preview-content">
                {doc.content && (
                  <>
                    {!expanded ? (
                      <Paragraph 
                        ellipsis={{ rows: 3, expandable: false }}
                        style={{ fontSize: '12px', margin: '8px 0 0 0' }}
                      >
                        {doc.content}
                      </Paragraph>
                    ) : (
                      <Paragraph style={{ fontSize: '12px', margin: '8px 0 0 0' }}>
                        {doc.content}
                      </Paragraph>
                    )}
                    {!expanded ? (
                      <Button type="link" size="small" onClick={() => handleExpand(doc.id)} style={{ padding: 0 }}>
                        more
                      </Button>
                    ) : (
                      <Button type="link" size="small" onClick={() => handleCollapse(doc.id)} style={{ padding: 0 }}>
                        hide
                      </Button>
                    )}
                  </>
                )}
                {!doc.content && (
                  <Text type="secondary" style={{ fontSize: '12px' }}>
                    {doc.type && doc.type.includes('pdf') ? 'PDF文件，点击Preview预览' : '无内容预览'}
                  </Text>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      <Modal
        title={previewDocument?.name}
        open={previewVisible}
        onCancel={() => setPreviewVisible(false)}
        width={800}
        footer={[
          <Button key="download" icon={<DownloadOutlined />} onClick={() => {
            if (previewDocument?.file) {
              const url = URL.createObjectURL(previewDocument.file);
              const a = document.createElement('a');
              a.href = url;
              a.download = previewDocument.name;
              a.click();
              URL.revokeObjectURL(url);
            }
          }}>
            Download
          </Button>,
          <Button key="close" onClick={() => setPreviewVisible(false)}>
            Close
          </Button>
        ]}
      >
        {previewDocument && (
          <div style={{ 
            height: '500px', 
            overflow: 'auto', 
            padding: '16px',
            background: '#fafafa',
            border: '1px solid #d9d9d9',
            borderRadius: '4px'
          }}>
            <Text style={{ whiteSpace: 'pre-wrap', fontSize: '13px', lineHeight: '1.6' }}>
              {previewDocument.content || '无法显示文件内容'}
            </Text>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default DocumentManager;
