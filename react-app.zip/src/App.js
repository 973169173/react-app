import React from 'react';
import PromptStudio from './components/PromptStudio';
import 'antd/dist/reset.css';
import './App.css';

function App() {
  return (
    <div className="App">
      <PromptStudio />
    </div>
  );
}

export default App;
