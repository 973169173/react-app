import React from 'react';
import PromptStudio from '../components/PromptStudio';

const OperatorPage = () => {
  return <PromptStudio />;
};

export default OperatorPage;